// Qui va tutto il codice JavaScript completo di Nerdy Organizer
// gestione tab, comandi vocali, registratore, test avanzato, salvataggio dati, import/export, reset, tema
console.log('App.js caricata correttamente');